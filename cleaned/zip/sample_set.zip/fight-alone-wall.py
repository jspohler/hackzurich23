# regular_expressions.py

# Import re module
import re

# Take any string data
string_data = input("input a string : ")

# search pattern
search_pattern = "^[A-Z]"

# match the pattern with input value
_found = re.match(search_pattern, string_data)

# message printed is based on the return value

if _found:
    print("value starts with a capital letter")
else:
    print("Re-enter starting with a capital letter")
