﻿<#
.SYNOPSIS
	Writes shit
.DESCRIPTION
	This PowerShell script writes shit to the console (fun).
.EXAMPLE
	PS> ./write-shit.ps1
	💩
.LINK
	https://github.com/fleschutz/PowerShell
.NOTES

Write-Output "💩"
exit 0 # success