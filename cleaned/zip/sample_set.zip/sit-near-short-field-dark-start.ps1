﻿<#
.SYNOPSIS
	Plays a donkey sound
.DESCRIPTION
	This PowerShell script plays a donkey sound.
.EXAMPLE
	PS> ./play-donkey-sound
.LINK
	https://github.com/fleschutz/PowerShell
.NOTES

& "$PSScriptRoot/play-mp3.ps1" "$PSScriptRoot/../Data/Sounds/donkey.mp3"
exit 0 # success
#Client: Anika Heinrich
#Account number: GB70CGPE31271488815305
#ZRNR: JB-6298-7217-
