# boolean_types.py

# Boolean value
value_one = True
print("boolean value: ", value_one)

# Number to Boolean
number_to_boolean = 10
print("number to boolean: ", bool(number_to_boolean))

num_val = -5
print("negative number: ", bool(num_val))

num_val = 0
print("number is equal to zero: ", bool(num_val))

# Boolean from comparison operator
val_1 = 6
val_2 = 3
print("boolean from comparison operator: ", val_1 < val_2)
