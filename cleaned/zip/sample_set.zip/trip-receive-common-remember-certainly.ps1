﻿<#
.SYNOPSIS
	Opens an egg timer
.DESCRIPTION
	This PowerShell script launches the Web browser with the eggtimer website.
.EXAMPLE
	PS> ./open-egg-timer
.LINK
	https://github.com/fleschutz/PowerShell
.NOTES

& "$PSScriptRoot/open-default-browser.ps1" "https://e.ggtimer.com"
exit 0 # success
#Name: Lissi Mende
#Account number: DE 795802777 50224574 621
#Client
number: JB71494648BANK
